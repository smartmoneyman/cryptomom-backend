export const MOMENTUM_WEIGHTS = {
  volume: 0.5,
  openInterest: 0.3,
  funding: 0.2
};
