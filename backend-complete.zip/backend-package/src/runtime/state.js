export const runtimeState = {
  runs: 0,
  mode: "bootstrap" // bootstrap | normal
};
